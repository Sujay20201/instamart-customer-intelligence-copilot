# Instamart Customer Intelligence & Support Copilot

## Overview

An internal tool for a (fictional) quick-commerce company, built in four connected parts. Part A turns messy order exports into a trusted SQLite database. Part B segments customers and predicts who is likely to stop ordering. Part C triages support tickets with privacy and cost guardrails and routes them using the Part B segments. Part D answers policy questions from the documents (retrieval-augmented) and runs a refund agent that queries the Part A database. Every part consumes the outputs of the earlier ones.

All data is synthetic and produced by `generate_data.py`; all money is in Indian Rupees (INR). Every model call goes through the offline `mock_llm.py` (no API key, network or cost). The two supplied files `generate_data.py` and `mock_llm.py` are committed unmodified. Libraries: Python standard library, pandas, numpy, scikit-learn, joblib.

```
generate_data.py, mock_llm.py     supplied, unmodified
src/                              part_a_*.py, part_b_*.py, part_c_triage.py, rag.py, agent.py, part_d_run.py, build_readme.py
sql/queries.sql                   the seven Part A queries
data/raw, data/policies           generated inputs
data/clean, data/instamart.db     Part A outputs
outputs/                          segments, model, retention list, triage CSVs, agent runs, ledgers
reports/                          markdown fragments written by each script (assembled into this README)
state/                            agent checkpoints
```

## Reproduce

Python 3.11 or newer (developed and verified on Python 3.12). Run from the repository root, in this order:

1. `python -m venv venv`
2. `source venv/bin/activate` (Windows: `venv\Scripts\activate`)
3. `pip install -r requirements.txt`
4. `python generate_data.py` (last line printed: `generated: customers=1200 products=40 orders_raw=13084 tickets=164`)
5. `python src/part_a_clean.py` (audit, cleaning, CSV + SQLite)
6. `python src/part_a_validate.py` (prints `ALL CHECKPOINTS PASSED`)
7. `python src/part_a_sql.py` (runs `sql/queries.sql`)
8. `python src/part_a_eda.py`
9. `python src/part_b_segments.py` (RFM, K-means, PCA, `outputs/customer_segments.csv`)
10. `python src/part_b_lapse.py` (lapse model, `outputs/lapse_model.joblib`, `outputs/retention_list.csv`)
11. `python src/part_c_triage.py` (`outputs/triage_results.csv`, `outputs/triage_budget_demo.csv`)
12. `python src/part_d_run.py` (policy assistant evaluation, `outputs/agent_runs.jsonl`, ledgers, `state/`)
13. `python src/build_readme.py` (optional: regenerates this README from the numbers just produced)

Random seeds are fixed (`random_state=42`, `random.seed(42)` for retry jitter). Each script asserts the reference checkpoints it can check and stops with an error if one fails. `lapse_model.joblib` is tied to the scikit-learn version in `requirements.txt`.

## Part A

### Audit of the raw data

**customers.csv** — shape 1200 rows x 5 columns

| column | dtype | missing | missing_pct |
|---|---|---|---|
| customer_id | str | 0 | 0.00 |
| city | str | 0 | 0.00 |
| signup_date | str | 0 | 0.00 |
| age | float64 | 61 | 5.08 |
| gender | str | 30 | 2.50 |

**products.csv** — shape 40 rows x 4 columns

| column | dtype | missing | missing_pct |
|---|---|---|---|
| product_id | str | 0 | 0.00 |
| product_name | str | 0 | 0.00 |
| category | str | 0 | 0.00 |
| price_inr | int64 | 0 | 0.00 |

**orders.csv** — shape 13084 rows x 9 columns

| column | dtype | missing | missing_pct |
|---|---|---|---|
| order_id | str | 0 | 0.00 |
| customer_id | str | 0 | 0.00 |
| product_id | str | 0 | 0.00 |
| quantity | int64 | 0 | 0.00 |
| order_ts | str | 0 | 0.00 |
| status | str | 0 | 0.00 |
| discount_pct | int64 | 0 | 0.00 |
| order_amount | str | 53 | 0.41 |
| delivery_minutes | float64 | 2541 | 19.42 |

**Audit figures**

| check | value |
|---|---|
| raw orders.csv rows | 13,084 |
| exact duplicate rows | 119 |
| rows with status pending | 656 |
| distinct order_id | 12,309 |
| non-numeric order_amount | 120 |
| negative delivery_minutes | 106 |
| blank delivery_minutes | 2,541 |
| customers: blank age | 61 |
| customers: age outside 10-100 | 6 |
| customers: distinct raw city spellings | 24 |
| customers: distinct non-blank raw gender spellings | 10 |
| customers: blank gender | 30 |

### Customer cleaning rules and effect

| rule | rows/values changed |
|---|---|
| City: strip spaces + title case | 24 raw spellings -> 6 cities |
| Gender: map spellings to male/female, blank -> unknown | 950 values rewritten (incl. 30 blanks -> unknown) |
| Age: values outside 10-100 set to missing | 6 values set to missing |
| Age: fill missing with city median (groupby + transform) | 67 values filled (61 blank + 6 invalid) |
| signup_date -> datetime | 1200 values converted |

Cities after cleaning: Pune 227, Delhi 210, Bengaluru 197, Chennai 191, Hyderabad 191, Mumbai 184. Genders: female 610, male 560, unknown 30. Missing ages: 0; age range 18-60.

### Order cleaning rules and effect

| rule (in order) | effect | rows after |
|---|---|---|
| 1. order_ts -> datetime | 13084 values converted | 13084 |
| 2. Remove exact duplicate rows | 119 rows removed | 12965 |
| 3. Keep latest order_ts per order_id | 656 earlier (pending) records removed | 12309 |
| 4. order_amount numeric; fill missing from price x qty x (1-disc) | 112 amounts rebuilt | 12309 |
| 5. Negative delivery -> missing; completed filled with category median; cancelled left missing | 105 negatives set to missing; 774 completed values filled (incl. negatives); cancelled untouched | 12309 |

After cleaning: 12,309 rows; completed 11,110; cancelled 1,199; pending 0; missing order_amount 0; missing delivery_minutes among completed 0, among cancelled 1,199; completed revenue INR 2,998,668.80.

Stored `data/clean/customers.csv`, `products.csv`, `orders.csv` and SQLite `data/instamart.db` (tables customers=1200, products=40, orders=12309; order_ts stored as text).

The validation script `src/part_a_validate.py` asserts 12 checkpoints (row counts, status counts, no pending rows, missing-value rules, completed revenue of INR 2,998,668.80, city and gender counts, age range, database tables and database totals) and prints exactly `ALL CHECKPOINTS PASSED` when all hold.

### SQL results (all from `sql/queries.sql`, completed orders only unless stated)

| query | result |
|---|---|
| Q1 WHERE + HAVING | 30 customers |
| Q2 three-table join | 30 rows; revenue sums to INR 2,998,668.80; largest cell Bengaluru / Electronics INR 233,909.45 |
| Q3 scalar subquery | 11 products above average catalogue price |
| Q4 LEFT JOIN | 25 customers with no completed order |
| Q5 CTE | 550 customers above the average; average spend INR 2,552.06 |
| Q6 window ranks | 1175 rows; 8 rows with RANK() different from ROW_NUMBER() |
| Q7 running total | 183 daily rows; last cumulative INR 2,998,668.80 |

Top customer per city (Q6):

| city | customer_id | total_spend |
|---|---|---|
| Bengaluru | C0082 | 12,856.20 |
| Chennai | C0930 | 10,151.40 |
| Delhi | C0291 | 13,742.60 |
| Hyderabad | C0743 | 12,730.05 |
| Mumbai | C0693 | 14,766.55 |
| Pune | C0426 | 10,377.10 |

Why RANK() and ROW_NUMBER() differ: when two customers in a city have exactly the same total spend, RANK() gives them the same rank and skips the next number, while ROW_NUMBER() always counts 1, 2, 3 and breaks the tie arbitrarily, so the two columns disagree for tied customers and for every row after them.

### pandas cross-check

`pd.pivot_table(..., margins=True)` grand total = INR 2,998,668.80, equal to the SQL Q2 total (INR 2,998,668.80). Pivot (INR):

| city | Dairy | Electronics | Grocery | Personal Care | Snacks | Total |
|---|---|---|---|---|---|---|
| Bengaluru | 87,075.05 | 233,909.45 | 110,915.65 | 20,193.85 | 71,549.40 | 523,643.40 |
| Chennai | 78,301.80 | 195,508.80 | 93,817.45 | 27,675.40 | 68,325.70 | 463,629.15 |
| Delhi | 117,271.70 | 158,549.10 | 112,658.05 | 23,471.50 | 90,879.45 | 502,829.80 |
| Hyderabad | 83,731.00 | 228,913.10 | 109,475.40 | 24,800.05 | 81,670.35 | 528,589.90 |
| Mumbai | 75,209.85 | 214,738.40 | 78,970.15 | 38,018.00 | 72,122.10 | 479,058.50 |
| Pune | 90,349.55 | 187,629.25 | 108,456.60 | 34,275.15 | 80,207.50 | 500,918.05 |
| Total | 531,938.95 | 1,219,248.10 | 614,293.30 | 168,433.95 | 464,754.50 | 2,998,668.80 |

Per-city completed order_amount (groupby + named aggregation):

| city | sum | mean | count |
|---|---|---|---|
| Bengaluru | 523,643.40 | 276.47 | 1894 |
| Chennai | 463,629.15 | 272.72 | 1700 |
| Delhi | 502,829.80 | 243.62 | 2064 |
| Hyderabad | 528,589.90 | 284.95 | 1855 |
| Mumbai | 479,058.50 | 297.00 | 1613 |
| Pune | 500,918.05 | 252.48 | 1984 |

Completed order_amount statistics:

| statistic | value |
|---|---|
| mean | 269.91 |
| median | 135.00 |
| skewness | 4.61 |
| Q1 | 64.80 |
| Q2 (median) | 135.00 |
| Q3 | 297.00 |
| lower fence | -283.50 |
| upper fence | 645.30 |
| outliers below lower fence | 0.00 |
| outliers above upper fence | 897.00 |

Correlation matrix (completed orders):

| index | order_amount | discount_pct | quantity | delivery_minutes |
|---|---|---|---|---|
| order_amount | 1.000 | -0.095 | 0.087 | -0.003 |
| discount_pct | -0.095 | 1.000 | -0.000 | -0.010 |
| quantity | 0.087 | -0.000 | 1.000 | -0.013 |
| delivery_minutes | -0.003 | -0.010 | -0.013 | 1.000 |

Largest absolute correlation: **order_amount vs discount_pct** = -0.095.

**Four questions (under 200 words)**

1. *What is this data about?* Six months (April-September 2025) of quick-commerce orders from 1,200 synthetic customers across six cities, 40 products in five categories; 11,110 completed orders worth INR 2,998,669.
2. *Distributions and statistics?* Order values are strongly right-skewed: mean INR 269.91 against median INR 135.00, skewness 4.61; most baskets are small grocery and snack items.
3. *Outliers or anomalies?* 897 orders lie above the upper fence of INR 645.30 (none below); 70.8% of them are electronics, so they are genuine high-value purchases, not errors. The real anomalies were in the raw data (duplicates, negative delivery times, text amounts) and were cleaned.
4. *Relationships?* All correlations are weak; the largest in absolute value is order_amount with discount_pct (-0.095). A correlation this small does not establish causation: it only says heavier discounts go slightly with smaller baskets, and other factors such as product mix could explain it.

## Part B

### RFM table (snapshot 2025-10-01 00:00:00, completed orders only)

1,175 customers have at least one completed order.

| column | median | min | max | mean |
|---|---|---|---|---|
| recency (days) | 19.00 | 0.00 | 180.00 | 33.56 |
| frequency | 5.00 | 1.00 | 33.00 | 9.46 |
| monetary (INR) | 2,286.50 | 12.00 | 14,766.55 | 2,552.06 |

### K-means (StandardScaler, n_init=10, random_state=42)

| K | inertia | silhouette |
|---|---|---|
| 2 | 1,820.800 | 0.465 |
| 3 | 1,268.200 | 0.445 |
| 4 | 743.100 | 0.526 |
| 5 | 617.400 | 0.480 |
| 6 | 503.200 | 0.482 |
| 7 | 408.500 | 0.416 |
| 8 | 366.500 | 0.412 |

**Choice: K = 4.** The elbow is at K=4: inertia falls from 1,268 (K=3) to 743 (K=4), a drop of 525, then only 126 from K=4 to K=5, and the silhouette peaks at K=4 (0.526, versus 0.445 at K=3 and 0.480 at K=5). Four segments is also a number a retention team can run four distinct campaigns for.

Why K=8 always has lower inertia than K=2 yet that cannot pick K: inertia is the sum of squared distances to the assigned centre, so adding centres can only shrink it (at K = number of customers it would be 0). A falling inertia is therefore guaranteed and carries no information by itself; the useful signals are where the *rate* of decrease flattens (the elbow), whether clusters stay well separated (silhouette) and whether the business can act on them.

### Segment profile (K=4)

Cluster numbers are only labels with no ordering: segment 0 is not 'lower' than segment 3. The names below come from each segment's mean RFM, and Premium is the segment with the highest mean monetary value.

| segment_id | segment_name | size | mean_recency | mean_frequency | mean_monetary | is_premium |
|---|---|---|---|---|---|---|
| 0 | Occasional shoppers | 436 | 28.9 | 3.8 | 1,057.6 | False |
| 1 | Premium high-spenders | 138 | 24.1 | 6.8 | 7,129.7 | True |
| 2 | Loyal regulars | 419 | 8.8 | 19.4 | 3,410.0 | False |
| 3 | Drifting / at-risk | 182 | 109.0 | 2.2 | 686.0 | False |

| segment_name | recommended_action |
|---|---|
| Occasional shoppers | Low-cost nudges (free-delivery threshold reminders, bundles) to raise basket size and order frequency. |
| Premium high-spenders | Early access to electronics drops, priority support and a retention call before they go quiet. |
| Loyal regulars | Keep them engaged with a subscription or streak reward; do not spend heavy discounts on people who already order weekly. |
| Drifting / at-risk | Win-back push within days: a time-limited coupon on their usual category before the gap becomes permanent. |

PCA(n_components=2) on the scaled RFM matrix: explained_variance_ratio_ = 0.634 and 0.218, total 0.852.

Wrote `outputs/customer_segments.csv` (1,175 rows; Premium = segment 1, 138 customers).

### Lapse problem definition

Cutoff 2025-09-01. Cohort: customers with at least one completed order before the cutoff = **1,156** customers. Label `lapsed` = 1 if no completed order dated 2025-09-01 to 2025-09-30. **443 lapsed (38.32%)**. Split `train_test_split(test_size=0.2, stratify=y, random_state=42)`: 924 training rows, 232 test rows.

Features (all built only from orders dated before 2025-09-01 plus the customer table): recency, frequency, monetary, average discount_pct, cancellation rate, average delivery_minutes, favourite category, city, age, gender, tenure_days. The segment labels from task 3 were **not** used as features (they were computed on the whole window including September and would leak the answer).

### Preprocessing without leakage

Every scaler and one-hot encoder lives inside a scikit-learn `Pipeline`, so it is fitted on the training rows only (inside each CV fold during tuning) and only applied to test rows. One-hot encoding uses `OneHotEncoder(drop="first")` (k-1 columns per variable); numeric columns use `StandardScaler`. No encoder, scaler or resampler saw test rows, and no data from 2025-09-01 onwards entered the features.

Learned scaler mean of `frequency` (training rows): **8.115**; full-cohort mean of `frequency`: **8.029**. They differ because the scaler was fitted on the 924 training customers only, a random 80% sample, so its mean is that sample's mean and not the whole cohort's. Missing values in the feature matrix: 0 (asserted in code).

### Training, tuning and test evaluation (lapsed = positive class)

**Baseline** (always predict 'not lapsed') on the test set: accuracy 61.6%, precision 0.00, recall 0.00, lapsed-class F1 0.00.

**Logistic regression** `GridSearchCV` C in {0.01, 0.1, 1, 10, 100}, cv=5, scoring=f1: best {'clf__C': 100}, best CV F1 0.651.

**Random forest** `GridSearchCV` max_depth in {3, 5, 8} x min_samples_leaf in {5, 10, 20}, cv=5, scoring=f1 (45 fits): best {'clf__max_depth': 8, 'clf__min_samples_leaf': 10}, best CV F1 0.681.

Test-set results (untouched until tuning finished):

| model | TN | FP | FN | TP | precision | recall | F1 |
|---|---|---|---|---|---|---|---|
| Logistic regression | 111 | 32 | 31 | 58 | 0.644 | 0.652 | 0.648 |
| Random forest | 113 | 30 | 31 | 58 | 0.659 | 0.652 | 0.655 |

**Selected model: Random forest** (higher cross-validated F1, 0.681, chosen on training data alone; the test set then confirms F1 0.655, recall 0.652, precision 0.659, versus logistic regression F1 0.648). Missing a lapsing customer means losing the recurring revenue of a customer we could have saved, whereas wrongly targeting a loyal one costs only a small coupon or message, so recall matters more than precision here; the selected model catches 58 of the 89 lapsing test customers at the price of 30 false alarms. F1 0.66 is well above the always-'not lapsed' baseline of 0.

### Class-balance experiment

Over-sampled the training set only: kept all 924 original rows and added 216 random duplicates of lapsed training rows (with replacement, random_state=42), giving 570 rows per class. The test set was not touched and the pipeline's scaler and encoder were fitted on the balanced training data only.

| model | precision | recall | F1 |
|---|---|---|---|
| Logistic regression, original | 0.644 | 0.652 | 0.648 |
| Logistic regression, balanced | 0.589 | 0.854 | 0.697 |

Recall moved most (0.65 to 0.85, a change of +0.20) while precision changed by -0.06. For the retention team that means the balanced model finds many more of the customers who would leave, but it also flags more loyal customers by mistake, so the choice depends on how cheap the retention offer is.

### Interpretation, persistence and retention list

**Top five random-forest features** (`feature_importances_`):

| feature | importance | business reading |
|---|---|---|
| num__frequency | 0.280 | how often a customer orders is a strong sign of habit. |
| num__monetary | 0.271 | total spend reflects how valuable and engaged the customer is. |
| num__recency | 0.115 | the longer since the last order, the likelier the customer is to lapse. |
| num__avg_delivery_minutes | 0.061 | slow deliveries can push customers away. |
| num__cancel_rate | 0.052 | frequent cancellations signal a poor experience. |

**Logistic-regression coefficient signs** (positive = pushes towards lapsed; features standardised):

| feature | coefficient | sign | business reading |
|---|---|---|---|
| recency | 0.039 | + | longer gap since the last order raises lapse risk |
| frequency | -1.697 | - | more orders lower lapse risk - frequent buyers stay |
| cancel_rate | -0.124 | - | a higher cancellation rate lowers lapse risk |

Magnitude matters: frequency (-1.70) dominates, while recency (+0.04) and cancel_rate (-0.12) are close to zero, so only frequency is a reliable signal. The cancel_rate sign runs against intuition; with a coefficient this small it should be read as noise (the synthetic data does not link cancellations to lapsing), not as a business finding.

Saved the selected Random forest pipeline to `outputs/lapse_model.joblib`; the reloaded model reproduces the original test predictions exactly: **True** (232 predictions compared).

`outputs/retention_list.csv`: top 10 Premium test customers by predicted lapse probability (40 Premium customers in the test set); **1 of these 10 truly lapsed**. The Premium flag comes from whole-window RFM that includes September (the window that defines the lapse label), so this retention list is illustrative and not a leakage-free evaluation (the model's own features still use only pre-cutoff orders).

## Part C

### Input guardrails

164 tickets. Empty or whitespace-only tickets get `skipped_empty`: **4**. Tickets with est_tokens > 400 get `flagged_long`: **4** (each estimates to 734 tokens). Neither kind is ever sent to the model.

### Redaction (applied in order: email, phone, order id)

| type | substitutions |
|---|---|
| email | 55 |
| phone | 91 |
| order id | 132 |
| total | 278 |

Re-applying the three patterns to the redacted texts finds **0** matches. The user message sent to the model is exactly the redacted ticket text.

### Prompts

Zero-shot system prompt:

```
You CLASSIFY customer support tickets. Allowed categories: billing, delivery, technical, fraud. Reply with JSON only, exactly {"category": "...", "reason": "..."} and nothing else.
```

Few-shot system prompt:

```
You CLASSIFY customer support tickets. Allowed categories: billing, delivery, technical, fraud. Reply with JSON only, exactly {"category": "...", "reason": "..."} and nothing else.
EXAMPLES:
Ticket: I was charged twice for [ORDER_ID], please refund the extra payment. -> {"category": "billing", "reason": "duplicate charge"}
Ticket: My order has not arrived and the rider is not picking up calls. -> {"category": "delivery", "reason": "late or missing order"}
Ticket: The app freezes when I apply a coupon and shows an error. -> {"category": "technical", "reason": "app malfunction"}
Ticket: Someone hacked my account, this is fraud on my wallet. -> {"category": "fraud", "reason": "unauthorised account use"}
Ticket: There is an unauthorized transaction on my card that I did not place. -> {"category": "fraud", "reason": "unauthorised transaction"}
```

### Resilient calls and validation (one full run over the 156 eligible tickets)

Transient errors in the zero-shot run: **19**, recovered by a retry: **19**, permanent errors: **0**. Retry log (`outputs/retry_log.txt`, one line per retry) wait range: 0.0453-0.0562 s; every retry here is retry number 0, so each wait must lie in [0.0450, 0.0575] s (asserted in code). Backoff: BASE_DELAY x 2**n x random.uniform(0.9, 1.15), BASE_DELAY = 0.05 s, max 3 retries per ticket, `random.seed(42)`.

Status counts, zero-shot run:

| status | tickets |
|---|---|
| classified_json | 135 |
| classified_keyword | 12 |
| flagged_invalid_output | 9 |
| skipped_empty | 4 |
| flagged_long | 4 |

### Zero-shot versus few-shot

| run | classified | accuracy | total tokens | tokens per classified ticket |
|---|---|---|---|---|
| zero-shot | 147 | 85.7% (126/147) | 9088 | 61.8 |
| few-shot | 147 | 100.0% (147/147) | 29056 | 197.7 |

Zero-shot confusion table (rows = true category, columns = predicted):

| true | billing | delivery | fraud | technical |
|---|---|---|---|---|
| billing | 38 | 0 | 0 | 0 |
| delivery | 0 | 36 | 0 | 0 |
| fraud | 11 | 0 | 23 | 0 |
| technical | 10 | 0 | 0 | 29 |

Few-shot costs 135.8 more tokens per classified ticket (29,056 versus 9,088 in total, +220%) but lifts accuracy from 85.7% to 100.0%. The zero-shot errors are 11 fraud tickets sent to billing and 10 technical tickets sent to billing; a fraud ticket in the billing queue misses the 2-hour security SLA, so for this workload the extra tokens are well worth paying. For a low-stakes category where a wrong label costs nothing, the cheaper zero-shot prompt would be the better trade.

### Token budget demo

Zero-shot run with TOKEN_BUDGET = 6000: tokens spent 6,018; **53 tickets ended `budget_exhausted`** (routed to human review, no model call made). Saved as `outputs/triage_budget_demo.csv`.

### Final triage and routing

Final run: few-shot prompt, TOKEN_BUDGET = 100000, saved as `outputs/triage_results.csv` (164 rows, input order preserved).

| route | priority | tickets |
|---|---|---|
| human_review | NORMAL | 17 |
| premium_desk | HIGH | 11 |
| security_team | HIGH | 34 |
| support_queue | NORMAL | 102 |

**Rule-validated and routed automatically:** 147 tickets (135 valid JSON, 12 accepted by the single-keyword rule). **Sent to humans:** 17 tickets (4 empty, 4 too long, 9 invalid model output, 0 budget exhausted). Nothing was guessed.

PII assertion: checked all 640 message lists sent to the model across every run; none contains an email, phone number or order id.

## Part D

### Chunking (40 words, overlap 10)

| document | chunks |
|---|---|
| delivery_policy.txt | 3 |
| escalation_policy.txt | 3 |
| payment_policy.txt | 3 |
| privacy_policy.txt | 2 |
| refund_policy.txt | 4 |
| total | 15 |

### Retrieval (TF-IDF + cosine similarity)

Query `refund policy late delivery`, top 3: refund_policy.txt (0.272), refund_policy.txt (0.251), refund_policy.txt (0.245) - all three from `refund_policy.txt`.

TF (term frequency) measures how often a word occurs inside one chunk, and IDF (inverse document frequency) down-weights words that appear in many chunks so that rare, distinctive words count more. A limitation for this task is that TF-IDF matches words, not meaning: a question phrased as 'money back' would not match a chunk that says 'refund', and the question 'how soon is money returned' only works because it shares words such as 'deducted' or 'returned' with the text.

### Policy assistant evaluation (`data/raw/policy_eval.csv`: 12 answerable, 2 unanswerable)

| setting | chunks | expected doc in top 3 | answer contains expected fact | unanswerable -> fallback |
|---|---|---|---|---|
| 40 words, overlap 10 | 15 | 12/12 | 12/12 | 2/2 |
| 40 words, overlap 0 | 13 | 12/12 | 10/12 | 2/2 |

Questions that fail with overlap 0:

| question | expected fact | answer given |
|---|---|---|
| What delivery time makes a completed order eligible for a full refund? | more than 45 minutes | receives a full refund of the order amount. |
| How soon is money returned when a payment fails but is deducted? | 48 hours | If a payment fails but money is deducted, the amount is returned automatically   1000 must be approved by a human support lead before money is returned. |

With overlap 0, 2 answerable questions break: *"What delivery time makes a completed order eligible for a full refund?"* (expected `more than 45 minutes`); *"How soon is money returned when a payment fails but is deducted?"* (expected `48 hours`). In both, the expected document is still among the top three, so retrieval is not the problem; the single sentence that holds the fact is cut in two at a 40-word boundary. The assistant only sees the half that matches the question's words, and that half does not contain the fact (for example the half ending in 'the amount is returned automatically' without 'within 48 hours'). With a 10-word overlap the end of each chunk is repeated at the start of the next, so these sentences stay whole in at least one chunk, which is why all 12 answers are correct.


### Tools

| tool | description | parameters |
|---|---|---|
| get_order | Look up an order by id in the Instamart database. | order_id |
| search_policy | Search the policy documents and return the three most relevant chunks. | query |
| calculate_refund | Compute the refund in INR from the order amount and delivery minutes. | order_amount, delivery_minutes |
| issue_refund | Issue an automatic refund (up to INR 1000) and record it in the ledger. | order_id, refund_inr |
| escalate_to_human | Send a refund above INR 1000 to a human support lead and record it in the ledger. | order_id, refund_inr |

The model asks for a tool by name with an `arguments` dictionary; `TOOL_MAP[name](**arguments)` runs it. Refund rules: only completed orders; delivery over 45 minutes = 100% of `order_amount`, otherwise 0; above INR 1000 the case is escalated, not issued.

### Seven scenarios (ReAct loop, max_iterations=6, token_limit=6000, time_limit_seconds=10)

| scenario | status | refund (INR) | model calls | tokens used |
|---|---|---|---|---|
| S1 | REFUND | 128.25 | 5 | 1067 |
| S2 | REFUND | 135.00 | 5 | 1067 |
| S3 | ESCALATE | 1,999.00 | 5 | 1054 |
| S4 | DENIED | 0.00 | 4 | 741 |
| S5 | DENIED | 0.00 | 3 | 439 |
| S6 | NOT_FOUND | 0.00 | 2 | 140 |
| S7 | FALLBACK_MAX_ITERATIONS | 0.00 | 6 | 3204 |

All seven results match `expected_outcome` and `expected_refund_inr` (within INR 0.01); S7 ends with `FALLBACK_MAX_ITERATIONS` under the default token limit. Details: `outputs/agent_runs.jsonl`; ledger: `outputs/refund_ledger.jsonl`; checkpoints: `state/`.

### Stop-safely demonstrations

| demo | status | model calls | tokens used | tools executed |
|---|---|---|---|---|
| S1 with token_limit=200 | FALLBACK_TOKEN_LIMIT | 3 | 456 | 2 |
| S1 with time_limit_seconds=0 | FALLBACK_TIMEOUT | 0 | 0 | 0 |
| S7 with default limits | FALLBACK_MAX_ITERATIONS | 6 | 3204 | 6 |

Token-limit demo: the limit was crossed at 456 tokens, so the tool requested in that call was **not** executed. Hand-off text: *HANDOFF: automated agent stopped (token limit 200 exceeded at 456) for scenario S1 after 3 model calls and 2 tool steps (get_order -> search_policy). Please review this request manually.*

### Crash and resume (S1)

A simulated crash was raised right after the second tool execution and its checkpoint (`state/S1-demo-crash.json`): *simulated crash after tool #2 (search_policy)*. Checkpoint at the crash: tools executed so far = get_order, search_policy. `resume_agent('S1-demo-crash')` loaded it and continued without repeating anything.

**Tools executed across the crash and the resume, in order:** get_order, search_policy, calculate_refund, issue_refund (4 executions, none repeated). Final status **REFUND**, refund INR 128.25, 5 model calls in total. The demo runs write to `outputs/refund_ledger_demo.jsonl`, not the main ledger, so order S1 is not paid twice in the main ledger.

### ReAct versus plan-and-execute

**ReAct versus plan-and-execute.** Our ReAct agent asks the model before every step, so it costs one call per tool plus one for the answer: 5 calls and 1,067 tokens for S1 (four tools), 3 calls for the cancelled order S5 and 2 for the unknown order S6. Each call re-sends the growing history, so tokens grow faster than calls. A plan-and-execute design would ask once for the whole step list (get order, search policy, calculate, issue) and then run it with no further model calls, so S1 would need about two calls (plan and final answer) and far fewer tokens. Its weakness is the unexpected observation: when get_order returns *order not found* (S6) or the order is cancelled (S5), the remaining planned steps are pointless or wrong, and the executor must detect the surprise and trigger a replan, which costs another call and needs extra code. ReAct handles both cases for free: it sees the observation and stops after only 2 or 3 calls, which is the real behaviour we measured. For this refund workflow I would choose ReAct: the flow is short (at most five steps), 3 of our 7 scenarios (S4, S5, S6) end in a denial or not-found, and money is involved, so reacting to each observation, checkpointing after every tool and refusing to continue on surprises is worth the extra tokens. Plan-and-execute becomes attractive only if volumes grow and the flow stays predictable.

*(237 words)*

## Limitations and Next Steps

**Limitations**

- **Synthetic data and a mock model.** Segments, the lapse model and the triage accuracies describe generated data and a keyword-based mock, not real customers or a real language model. The 100% few-shot accuracy and the 85.7% zero-shot accuracy are properties of the mock's keyword ordering, so they do not predict how a hosted model would behave.
- **The retention list is illustrative.** The Premium flag comes from the whole-window RFM of task 3, which includes September (the window that defines the lapse label), so it is a post-hoc whole-window label; the retention list is illustrative and not a leakage-free evaluation. The model's own features use only orders before 2025-09-01.
- **Small test set.** The lapse model is judged on 232 test customers (89 lapsed), so an F1 difference of 0.01 between logistic regression and the random forest is within noise; one train/test split and no confidence intervals were used.
- **Weak coefficients.** Only `frequency` is a strong logistic-regression signal; the `recency` and `cancel_rate` coefficients are near zero and their signs should not be read as business findings.
- **Cleaning choices.** Median imputation (age by city, delivery time by category) is simple and hides uncertainty; imputed delivery times can change refund decisions for orders near the 45-minute line. Cancelled orders keep a missing delivery time on purpose.
- **Retrieval is lexical.** TF-IDF cannot match synonyms, and the mock assistant returns a single best sentence, so multi-sentence answers are not covered.
- **Token counts are estimates.** `est_tokens` is words x 1.3, not a real tokenizer, and the few-shot prompt costs about three times the zero-shot prompt per ticket.
- **Refund agent safety.** Refund tools have no idempotency key, so a retried request could pay twice; the crash-and-resume demo therefore writes to a separate demo ledger. The agent trusts the mock's tool requests and the SQLite file has no concurrent-write protection.

**Next steps**

- Evaluate the lapse model with repeated cross-validation and calibrate its probabilities; build the retention list only from customers flagged before the label window.
- Replace the mock with a hosted model behind the same `chat()` interface and re-measure accuracy, tokens and retries.
- Use embeddings or hybrid (BM25 + dense) retrieval and sentence-aware chunking for the policy assistant.
- Add idempotency keys and an approval queue to `issue_refund` and `escalate_to_human`, and move the database to a server with proper transactions.
- Add monitoring for data drift in the order exports and for classifier disagreement in triage.
